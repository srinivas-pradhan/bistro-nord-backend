import { 
    PutDBItem,
    QueryDBUsingBookingNumber,
    DeleteItem
 } from "../core/dynamodb/dynamoInteractor.mjs";

 import middy from "@middy/core";
 import validator from "@middy/validator";
 import { transpileSchema } from '@middy/validator/transpile'
 import httpErrorHandler from "@middy/http-error-handler";
 import { DoneWithAReservationSchema as Request } from '../core/middleware/RequestValidation.mjs';
 import { DoneWithAReservationSchema as Response } from "../core/middleware/ResponseValidation.mjs";

const BookingNumber = process.env.BOOKING_NUMBER;
const Done_Table = process.env.DONE_TABLE_NAME;

const DoneWithAReservation = async (event) => {
    console.log('OrderId:', event.pathParameters.OrderId)
    console.log('Status:', event.pathParameters.Status)
    try {
        var GetBookingNumber = await QueryDBUsingBookingNumber(BookingNumber, event.pathParameters.OrderId);
        GetBookingNumber.Items[0].Status.S = event.pathParameters.Status
        console.log(JSON.stringify(GetBookingNumber))
        const DoneItem = GetBookingNumber.Items[0]
        const Done_Booking = await PutDBItem(DoneItem, Done_Table)
        console.log(JSON.stringify(Done_Booking))
    } catch (error) {
        console.log(error)
    }
};

export const DoneWithAReservationHandler = middy(DoneWithAReservation)
  .use(
    validator({
      eventSchema: transpileSchema(Request),
      Response
    })
  )
  .use({
    onError: (request) => {
      const response = request.response;
      const error = request.error;
      if (response.statusCode != 400) return;
      if (!error.expose || !error.cause) return;
      response.headers["Content-Type"] = "application/json";
      response.body = JSON.stringify({ message: response.body, validationErrors: error.cause });
    },
  })
  .use(httpErrorHandler());
