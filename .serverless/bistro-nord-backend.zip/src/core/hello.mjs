export const Hello = () => {
    console.log("hello world")
}
